<div class="x_content table-responsive">
                    <table  id="datatable-fixed-header" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>Encuesta</th>
                          <th>Fecha</th>
                          <th>Estado</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>


                      <tbody>
                          
                      @foreach($enc as $e)
                        <tr>
                          <td>{{\Carbon\Carbon::parse($e->created_at)->format('Y').'-'.$e->semestre}}</td>
                          <td>{{$e->created_at}}</td>
                          @if($e->estado=='1')
                          <td style="color: green;"><b>Activo</b></td>
                          @else
                          <td style="color: red;"><b>Inactivo</b></td>
                          @endif
                          <td>
                            @if($e->estado=='1')
                            {!!Form::open(['route'=>['adminencuesta.update', $e->id], 'method'=>'PUT'])!!} 
                              <input type="hidden" name="estado" value="0">
                              <a href="{{url('excel',$e->id)}}" title="Descargar Excel" style="color: green; font-size:2em; padding-right: 4px;"><i id="ico-plus" class="fa fa-file-excel-o"></i></a>
                              <button class="submit btn btn-danger btn-xs"" title="Desactivar" 
                              onclick="javascript:return conf('Desactivar');"> 
                              Desactivar</button>
                            {!!Form::close() !!}
                            @else
                            {!!Form::open(['route'=>['adminencuesta.update', $e->id], 'method'=>'PUT'])!!} 
                              <input type="hidden" name="estado" value="1">
                              <a href="{{url('excel',$e->id)}}" title="Descargar Excel" style="color: green; font-size:2em; padding-right: 4px;"><i id="ico-plus" class="fa fa-file-excel-o"></i></a>
                              <button class="submit btn btn-success btn-xs"" title="Activar" 
                              onclick="javascript:return conf('Activar');"> 
                              Activar</button>
                            {!!Form::close() !!}
                          @endif

                          </td>
                        </tr>    
                      @endforeach
                      </tbody>
                    </table>
</div>
<script type="text/javascript">
    function conf(msj){
    confirmar = confirm('¿Seguro que deseas '+msj+' esta encuesta?');
    return confirmar;
  }
</script>