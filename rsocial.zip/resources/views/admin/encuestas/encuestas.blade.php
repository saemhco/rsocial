@extends('master.admin')
@section('title','Encuestas')
@section('estilos')
  {!!Html::style('select2-4.0.3/dist/css/select2.min.css',['rel'=>'stylesheet'])!!}
  @include('master.extras.tablasEstilos')

    <style>
      #eliminar{
        color: red;
        opacity: 0.4;
        font-size: 2em;
        transition: 0.5s;
      }
      #eliminar:hover{
        opacity: 1;
      }
      #editar{
        color: blue;
        opacity: 0.4;
        font-size: 1.8em;
        transition: 0.5s;
      }
      #editar:hover{
        opacity: 1;
      }
      .estado{
        text-align: center;
        border-radius: 20px;
        font-family: 'Denk One', sans-serif;
        margin-top: 30%;
        padding: 0.2em;
      }
      
       #accion{
        list-style:none; /* Eliminamos los bullets */
        margin:0px; /* Quitamos los margenes */
        padding:0px; /* Quitamos el padding */
      }
      #accion>li {
        float:left; /* Hacemos que el menu se muestre horizontal */
        padding-left:10px;
      }
    </style>
@endsection
@section('contenido')
  @include('admin.encuestas.encuesta-nuevo')
<!--Cuerpo-->
<div class="col-md-12 col-sm-12 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <h2>Encuestas <a href="#" class="btn btn-round btn-success" data-toggle="modal" data-target="#NuevaEncuesta">Nuevo</a></h2>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <div class="col-xs-2">
        <ul class="nav nav-tabs tabs-right">
          <li class="active"><a href="#home" data-toggle="tab" aria-expanded="true">Principal</a>
          </li>
          <li class=""><a href="#docentes" data-toggle="tab" aria-expanded="false">Docentes</a>
          </li>
          <li class=""><a href="#estudiantes" data-toggle="tab" aria-expanded="false">Estudiantes</a>
          </li>
        </ul>
      </div>

      <div class="col-xs-10">
        <!-- Tab panes -->
        <div class="tab-content">
          <div class="tab-pane active" id="home">@include('admin.encuestas.principal')</div>
          <div class="tab-pane" id="docentes">@include('admin.encuestas.docentes')</div>
          <div class="tab-pane" id="estudiantes">@include('admin.encuestas.estudiantes')</div>
        </div>
      </div>

                    <div class="clearfix"></div>
    </div>
  </div>
</div>
<!--Fin Cuerpo-->

@endsection
@section('script')
  @include('master.extras.tablasScript')

  <script type="text/javascript">
  //Informacion
  </script>
  <!--Scripts Select2-curso-->
  {!!Html::script('select2-4.0.3/dist/js/select2.js')!!}
 
@endsection