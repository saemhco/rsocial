<div class="modal fade bs-example-modal-sm in" tabindex="-1" role="dialog" aria-hidden="true" id="eliminar">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel2">Eliminar</h4>
                        </div>
                        <div class="modal-body">
                          <p>¿Está seguro que desea eliminar a este estudiante?</p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                          <a href="" class="btn btn-primary" id="eliminar-e">¡Sí, eliminar!</a>
                        </div>

                      </div>
                    </div>
                  </div>